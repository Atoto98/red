

<?php $__env->startSection('content'); ?>

<div class="container bg-danger pb-5">
            <div class="col-sm-12">
                <h1 class="text-center font-weight-bold text-white mt-4 font-italic">PROYECTOS</h1>
            </div>
        <div class="col-sm-12 p-5 mb-5 bg-white">
            <div class="max-w-6xl mx-auto py-10 sm:px-6 lg:px-8">
                <div class="flex flex-col">
                    <div class="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div class="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                            <div class="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                                <table id="tabla" class="table table-bordered table-hover table-cell-border" style="width:100%">
                                    <thead class="bg-primary text-white">
                                        <tr>
                                            <th scope="col">Titulo</th>   
                                            <th scope="col">Autor</th>  
                                            <th scope="col">Departamento</th>
                                            <th scope="col">Nombre del proyecto</th> 
                                            <th scope="col">Ver Documento</th> 
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                                <td><?php echo e($proyecto->titulo); ?></td>
                                                <td><?php echo e($proyecto->autor); ?></td>
                                                <td><?php echo e($proyecto->departamento); ?></td>
                                                <td><?php echo e($proyecto->pdf); ?></td> 
                                                <td><a class="btn btn-dark" href="Archivo/<?php echo e($proyecto->pdf); ?>" target="blank_">Ver Documento</a></td>   
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>  
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appfront', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prueba\resources\views/proyectosV.blade.php ENDPATH**/ ?>