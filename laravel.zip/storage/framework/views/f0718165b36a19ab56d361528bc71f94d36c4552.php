<div>
    <img width=100% src=<?php echo e(URL::asset('Logo/logos.png')); ?>>
</div><?php /**PATH C:\xampp\htdocs\prueba\resources\views/footer.blade.php ENDPATH**/ ?>