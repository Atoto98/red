<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            EDITAR FOTO DE CARRUSEL
    </h2>
     <?php $__env->endSlot(); ?>

    <div>
        <div class="max-w-4xl mx-auto py-10 sm:px-6 lg:px-8">
            
                <form action="/carrusel/<?php echo e($carrusel->id); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>    
                    <?php echo method_field('PUT'); ?>
                <div class="mb-3">
                    <label for="" class="form-label">Descripcion</label>
                    <input id="descripcion" name="descripcion" type="text" class="form-control" value="<?php echo e($carrusel->descripcion); ?>">    
                </div>
                    <div class="mb-3">
                    <label for="" class="form-label">Link</label>
                    <input id="link" name="link" type="text" class="form-control" value="<?php echo e($carrusel->link); ?>">    
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Orden</label>
                    <input id="orden" name="orden" type="text" class="form-control" value="<?php echo e($carrusel->orden); ?>">    
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Imagen</label>
                    <input id="urlfoto" name="urlfoto" type="file" class="form-control" value="<?php echo e($carrusel->urlfoto); ?>">    
                </div>
                <a href="/carrusel" class="btn btn-secondary">Cancelar</a>
                <button type="submit" class="bg-primary btn btn-primary">Guardar</button>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\prueba\resources\views/carrusel/edit.blade.php ENDPATH**/ ?>