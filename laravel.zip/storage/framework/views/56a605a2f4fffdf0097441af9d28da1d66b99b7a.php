<?php $__env->startSection('content'); ?>
  <div class="col-sm-12">
      <h1 class="text-center font-weight-bold text-white mt-3 font-italic">DIFUSION TEC</h1>
  </div>
  <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
        <ul class="carousel-indicators">
            <?php $__empty_1 = true; $__currentLoopData = $carrusel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li data-target="#carouselExampleCaptions" data-slide-to="<?php echo e($item->orden); ?>" class="<?php if($loop->index==0): ?> active <?php endif; ?>"></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </ul>
        <div class="carousel-inner">
        <?php $__empty_1 = true; $__currentLoopData = $carrusel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <div class="carousel-item <?php if($loop->index==0): ?> active <?php endif; ?>">
            <img src="/CarruselFotos/<?php echo e($item->urlfoto); ?>" class="d-block w-100" alt="<?php echo e($item->descripcion); ?>">
            <div class="carousel-caption d-none d-md-block pb-5">
                <h3 class="w-100 text-white font-weight-bold"><?php echo e($item->descripcion); ?></h3>
                <a target="blank_" href="<?php echo e($item->link); ?>" class="btn btn-success my-2 my-sm-0g">IR</a>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?> 
        </div>
          <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>    
  </div>
  <div class="container bg-danger py-4"> </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appfront', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prueba\resources\views/welcome.blade.php ENDPATH**/ ?>