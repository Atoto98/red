<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            LISTA DE PROYECTOS
        </h2>
     <?php $__env->endSlot(); ?>

    <div>
        <div class="max-w-6xl mx-auto py-10 sm:px-6 lg:px-8">
            <div class="block mb-8">
               <a href="proyectos/create" class="btn btn-primary">SUBIR PROYECTO</a>
            </div>
            <div class="flex flex-col">
                <div class="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                    <div class="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                        <div class="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                            <table id="tabla" class="table table-bordered table-responsive table-hover table-cell-border" style="width:100%">
                                <thead class="bg-primary text-white">
                                    <tr>
                                        <th scope="col">Titulo</th>  
                                        <th scope="col">Fecha</th>  
                                        <th scope="col">Autor</th>  
                                        <th scope="col">Departamento</th>
                                        <th scope="col">Nombre del proyecto</th> 
                                        <th scope="col">Ver Documento</th> 
                                        <th scope="col">Editar</th> 
                                        <th scope="col">Eliminar</th> 
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                            <td><?php echo e($proyecto->titulo); ?></td>
                                            <td><?php echo e($proyecto->fecha); ?></td>
                                            <td><?php echo e($proyecto->autor); ?></td>
                                            <td><?php echo e($proyecto->departamento); ?></td>
                                            <td><?php echo e($proyecto->pdf); ?></td> 
                                            <td><a class="btn btn-dark" href="Archivo/<?php echo e($proyecto->pdf); ?>" target="blank_">Ver Documento</a></td>
                                            <td>
                                                <a href="/proyectos/<?php echo e($proyecto->id); ?>/edit" class="btn btn-info">Editar</a>  
                                            </td> 
                                            <td>
                                                <form action="<?php echo e(route('proyectos.destroy', $proyecto->id)); ?>" method="POST" onsubmit="return confirm('¿Estas seguro de borrar?');">
                                                    <input type="hidden" name="_method" value="DELETE">
                                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                    <input type="submit" class="btn btn-danger bg-danger " value="Delete">
                                                </form>         
                                            </td>      
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\prueba\resources\views/proyectos/index.blade.php ENDPATH**/ ?>