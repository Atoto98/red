<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            EDITAR MINUTA
    </h2>
     <?php $__env->endSlot(); ?>

    <div>
        <div class="max-w-4xl mx-auto py-10 sm:px-6 lg:px-8">
            
                <form action="/minutas/<?php echo e($minuta->id); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>    
                    <?php echo method_field('PUT'); ?>
                <div class="mb-3">
                    <label for="" class="form-label">Titulo</label>
                    <input id="titulo" name="titulo" type="text" class="form-control" value="<?php echo e($minuta->titulo); ?>">    
                </div>
                    <div class="mb-3">
                    <label for="" class="form-label">Fecha</label>
                    <input id="fecha" name="fecha" type="text" class="form-control" value="<?php echo e($minuta->fecha); ?>">    
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">PDF</label>
                    <input id="pdf" name="pdf" type="file" class="form-control" value="<?php echo e($minuta->pdf); ?>">    
                </div>
                <a href="/minutas" class="btn btn-secondary">Cancelar</a>
                <button type="submit" class="bg-primary btn btn-primary">Guardar</button>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\prueba\resources\views/latex/edit.blade.php ENDPATH**/ ?>